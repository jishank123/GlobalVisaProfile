import { useState, useEffect } from 'react';
import { usersAPI } from '../../../../services/api';
import { designSystem, componentStyles, hoverEffects, getStatusBadgeStyle } from '../../../../styles/designSystem';
import { validateEmail, validatePassword, validatePhone } from '../../../../utils/validation';

const UserManagement = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('clients');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState('');
  const [modalData, setModalData] = useState(null);
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    password: '',
    role: '',
    phone: '',
    company: '',
    country: ''
  });
  const [formErrors, setFormErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    loadUserManagement();
  }, []);

  const validateEmail = (email) => {
    // Check if email contains @
    if (!email.includes('@')) {
      return { isValid: false, message: 'Email must contain @' };
    }
    
    // Check if email has text before @
    const parts = email.split('@');
    if (parts[0].length === 0) {
      return { isValid: false, message: 'Email must have text before @' };
    }
    
    // Check if email has domain after @
    if (parts.length < 2 || parts[1].length === 0) {
      return { isValid: false, message: 'Email must have domain after @' };
    }
    
    // Check if domain contains a dot
    if (!parts[1].includes('.')) {
      return { isValid: false, message: 'Email domain must contain a dot (e.g., .com, .org)' };
    }
    
    // Check if there's text after the last dot
    const domainParts = parts[1].split('.');
    if (domainParts[domainParts.length - 1].length < 2) {
      return { isValid: false, message: 'Email must have valid extension (e.g., .com, .org, .net)' };
    }
    
    // Full email regex validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return { isValid: false, message: 'Please enter a valid email address' };
    }
    
    return { isValid: true, message: '' };
  };

  const validatePassword = (password) => {
    const minLength = 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

    return {
      isValid: password.length >= minLength && hasUpperCase && hasLowerCase && hasNumbers && hasSpecialChar,
      errors: {
        minLength: password.length < minLength,
        hasUpperCase: !hasUpperCase,
        hasLowerCase: !hasLowerCase,
        hasNumbers: !hasNumbers,
        hasSpecialChar: !hasSpecialChar
      }
    };
  };

  const validateForm = () => {
    const errors = {};

    // Required field validation
    if (!formData.first_name.trim()) errors.first_name = 'First name is required';
    if (!formData.last_name.trim()) errors.last_name = 'Last name is required';
    
    if (!formData.email.trim()) {
      errors.email = 'Email is required';
    } else {
      // Email validation using utility function
      const emailValidation = validateEmail(formData.email);
      if (!emailValidation.isValid && emailValidation.errors && emailValidation.errors.length > 0) {
        errors.email = emailValidation.errors[0]; // Show first error
      } else if (emailValidation.isValid) {
        // Check if email already exists
        const existingUser = users.find(user => user.email.toLowerCase() === formData.email.toLowerCase().trim());
        if (existingUser) {
          errors.email = 'Email already exists. Please use a different email address.';
        }
      }
    }
    
    if (!formData.password) {
      errors.password = 'Password is required';
    } else {
      // Password validation using utility function
      const passwordValidation = validatePassword(formData.password);
      if (!passwordValidation.isValid && passwordValidation.errors && passwordValidation.errors.length > 0) {
        errors.password = passwordValidation.errors[0]; // Show first error
      }
    }
    
    if (!formData.role) errors.role = 'Role is required';

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const loadUserManagement = async () => {
    try {
      setLoading(true);
      
      const response = await usersAPI.getAll();
      
      if (response.success) {
        const users = response.data || [];
        setUsers(users);
      } else {
        throw new Error(response.error?.message || 'Failed to load users');
      }

    } catch (error) {
      console.error('Error loading user management:', error);
      setUsers([]);
    } finally {
      setLoading(false);
    }
  };

  // Filter users by role/type (exclude deleted users)
  const getFilteredUsers = (type) => {
    // First filter out deleted users
    const activeUsers = users.filter(user => user.status !== 'deleted');
    
    switch (type) {
      case 'clients':
        return activeUsers.filter(user => user.role === 'client' && user.status !== 'inactive');
      case 'managers':
        return activeUsers.filter(user => ['lead_manager', 'crm_manager', 'project_manager'].includes(user.role) && user.status !== 'inactive');
      case 'employees':
        return activeUsers.filter(user => user.role === 'employee' && user.status !== 'inactive');
      case 'admins':
        return activeUsers.filter(user => user.role === 'admin' && user.status !== 'inactive');
      case 'inactive':
        return activeUsers.filter(user => user.status === 'inactive');
      default:
        return activeUsers;
    }
  };

  // Get user counts for each section (exclude deleted users)
  const getUserCounts = () => {
    const activeUsers = users.filter(user => user.status !== 'deleted');
    return {
      clients: activeUsers.filter(user => user.role === 'client').length,
      managers: activeUsers.filter(user => ['lead_manager', 'crm_manager', 'project_manager'].includes(user.role)).length,
      employees: activeUsers.filter(user => user.role === 'employee').length,
      admins: activeUsers.filter(user => user.role === 'admin').length,
      inactive: activeUsers.filter(user => user.status === 'inactive').length,
      total: activeUsers.length
    };
  };

  const formatRole = (role) => {
    const roleNames = {
      'admin': 'Admin',
      'lead_manager': 'Lead Manager',
      'crm_manager': 'CRM Manager',
      'project_manager': 'Project Manager',
      'employee': 'Employee',
      'client': 'Client'
    };
    return roleNames[role] || role;
  };

  const formatStatus = (status) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  const getRoleBadgeStyle = (role) => {
    const roleStyles = {
      'admin': {
        background: '#dc3545',
        color: 'white'
      },
      'lead_manager': {
        background: '#fd7e14',
        color: 'white'
      },
      'crm_manager': {
        background: '#6f42c1',
        color: 'white'
      },
      'project_manager': {
        background: '#e83e8c',
        color: 'white'
      },
      'employee': {
        background: '#20c997',
        color: 'white'
      },
      'client': {
        background: '#198754',
        color: 'white'
      }
    };
    return roleStyles[role] || { background: designSystem.colors.gray[400], color: 'white' };
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    
    // Enforce 20-character limit for password
    if (name === 'password' && value.length > 20) {
      return;
    }
    
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Real-time validation for email
    if (name === 'email' && value.trim()) {
      const emailValidation = validateEmail(value);
      if (!emailValidation.isValid && emailValidation.errors && emailValidation.errors.length > 0) {
        setFormErrors(prev => ({
          ...prev,
          email: emailValidation.errors[0]
        }));
      } else if (emailValidation.isValid) {
        // Check if email already exists
        const existingUser = users.find(user => user.email.toLowerCase() === value.toLowerCase().trim());
        if (existingUser) {
          setFormErrors(prev => ({
            ...prev,
            email: 'Email already exists. Please use a different email address.'
          }));
        } else {
          // Clear error if validation passes
          setFormErrors(prev => ({
            ...prev,
            email: ''
          }));
        }
      }
    } else if (name === 'email' && !value.trim()) {
      // Clear error when field is empty
      setFormErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    } 
    // Real-time validation for phone
    else if (name === 'phone' && value.trim()) {
      const phoneValidation = validatePhone(value);
      if (!phoneValidation.isValid && phoneValidation.errors && phoneValidation.errors.length > 0) {
        setFormErrors(prev => ({
          ...prev,
          phone: phoneValidation.errors[0]
        }));
      } else {
        // Clear error if validation passes
        setFormErrors(prev => ({
          ...prev,
          phone: ''
        }));
      }
    } else if (name === 'phone' && !value.trim()) {
      // Clear error when field is empty
      setFormErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    } else {
      // Clear error for other fields when user starts typing
      if (formErrors[name]) {
        setFormErrors(prev => ({
          ...prev,
          [name]: ''
        }));
      }
    }
  };

  const handleAddUser = async (e) => {
    e.preventDefault();
    
    // Validate form
    if (!validateForm()) {
      return;
    }

    try {
      const response = await usersAPI.create(formData);
      
      if (response.success) {
        alert('✅ User created successfully!');
        setShowAddModal(false);
        setFormData({
          first_name: '',
          last_name: '',
          email: '',
          password: '',
          role: '',
          phone: '',
          company: '',
          country: ''
        });
        setFormErrors({});
        loadUserManagement();
      } else {
        throw new Error(response.error?.message || 'Failed to create user');
      }
    } catch (error) {
      console.error('Error creating user:', error);
      if (error.message.includes('email already exists') || error.message.includes('USER_EXISTS')) {
        setFormErrors({ email: 'A user with this email already exists' });
      } else {
        alert(`❌ Error creating user: ${error.message}`);
      }
    }
  };

  const viewUserDetails = (user) => {
    setModalData(user);
    setModalType('view');
    setShowModal(true);
  };

  const editUser = async (userId) => {
    const user = users.find(u => u._id === userId);
    setModalData(user);
    setModalType('edit');
    setFormData({ ...formData, role: user.role });
    setShowModal(true);
  };

  const deleteUser = async (userId, userEmail) => {
    const user = users.find(u => u._id === userId);
    setModalData({ user, userEmail });
    setModalType('delete');
    setShowModal(true);
  };

  const toggleUserStatus = async (user) => {
    try {
      console.log('Toggling user status for:', user.email, 'Current status:', user.status);
      
      const newStatus = (user.status === 'active' || !user.status) ? 'inactive' : 'active';
      const response = await usersAPI.update(user._id, { status: newStatus });
      
      if (response.success) {
        alert(`✅ User ${newStatus === 'active' ? 'activated' : 'deactivated'} successfully!`);
        loadUserManagement();
      } else {
        throw new Error(response.error?.message || 'Failed to toggle user status');
      }
    } catch (error) {
      console.error('Error toggling user status:', error);
      alert(`❌ Error toggling user status: ${error.message}`);
    }
  };

  const handleModalClose = () => {
    setShowModal(false);
    setModalData(null);
    setModalType('');
  };

  const handleEditUser = async (userId, newRole) => {
    try {
      const response = await usersAPI.update(userId, { role: newRole });
      
      if (response.success) {
        alert('✅ User role updated successfully!');
        handleModalClose();
        loadUserManagement();
      } else {
        throw new Error(response.error?.message || 'Failed to update user role');
      }
    } catch (error) {
      console.error('Error updating user:', error);
      alert(`❌ Error updating user role: ${error.message}`);
    }
  };

  const handleDeleteUser = async (userId) => {
    try {
      const response = await usersAPI.delete(userId);
      
      if (response.success) {
        alert('✅ User deleted successfully!');
        handleModalClose();
        loadUserManagement();
      } else {
        throw new Error(response.error?.message || 'Failed to delete user');
      }
    } catch (error) {
      console.error('Error deleting user:', error);
      alert(`❌ Error deleting user: ${error.message}`);
    }
  };

  // Unified Modal Component
  const UnifiedModal = ({ show, onHide, type, data }) => {
    if (!show) return null;

    const getModalConfig = () => {
      switch (type) {
        case 'view':
          return {
            title: 'User Details',
            icon: 'fas fa-eye',
            color: designSystem.colors.primary,
            content: (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: designSystem.spacing.md }}>
                <div>
                  <label style={{ 
                    display: 'block',
                    fontSize: designSystem.typography.fontSize.sm,
                    color: designSystem.colors.gray[500],
                    marginBottom: designSystem.spacing.xs
                  }}>Name</label>
                  <div style={{ fontWeight: designSystem.typography.fontWeight.semibold }}>{data.first_name} {data.last_name}</div>
                </div>
                <div>
                  <label style={{ 
                    display: 'block',
                    fontSize: designSystem.typography.fontSize.sm,
                    color: designSystem.colors.gray[500],
                    marginBottom: designSystem.spacing.xs
                  }}>Email</label>
                  <div style={{ fontWeight: designSystem.typography.fontWeight.semibold }}>{data.email}</div>
                </div>
                <div>
                  <label style={{ 
                    display: 'block',
                    fontSize: designSystem.typography.fontSize.sm,
                    color: designSystem.colors.gray[500],
                    marginBottom: designSystem.spacing.xs
                  }}>Phone</label>
                  <div style={{ fontWeight: designSystem.typography.fontWeight.semibold }}>{data.phone || 'Not provided'}</div>
                </div>
                <div>
                  <label style={{ 
                    display: 'block',
                    fontSize: designSystem.typography.fontSize.sm,
                    color: designSystem.colors.gray[500],
                    marginBottom: designSystem.spacing.xs
                  }}>Role</label>
                  <div style={{ fontWeight: designSystem.typography.fontWeight.semibold }}>{formatRole(data.role)}</div>
                </div>
                <div>
                  <label style={{ 
                    display: 'block',
                    fontSize: designSystem.typography.fontSize.sm,
                    color: designSystem.colors.gray[500],
                    marginBottom: designSystem.spacing.xs
                  }}>Company</label>
                  <div style={{ fontWeight: designSystem.typography.fontWeight.semibold }}>{data.company || 'Not specified'}</div>
                </div>
                <div>
                  <label style={{ 
                    display: 'block',
                    fontSize: designSystem.typography.fontSize.sm,
                    color: designSystem.colors.gray[500],
                    marginBottom: designSystem.spacing.xs
                  }}>Country</label>
                  <div style={{ fontWeight: designSystem.typography.fontWeight.semibold }}>{data.country || 'Not specified'}</div>
                </div>
                <div>
                  <label style={{ 
                    display: 'block',
                    fontSize: designSystem.typography.fontSize.sm,
                    color: designSystem.colors.gray[500],
                    marginBottom: designSystem.spacing.xs
                  }}>Status</label>
                  <div style={{ fontWeight: designSystem.typography.fontWeight.semibold }}>{formatStatus(data.status || 'active')}</div>
                </div>
                <div>
                  <label style={{ 
                    display: 'block',
                    fontSize: designSystem.typography.fontSize.sm,
                    color: designSystem.colors.gray[500],
                    marginBottom: designSystem.spacing.xs
                  }}>Member Since</label>
                  <div style={{ fontWeight: designSystem.typography.fontWeight.semibold }}>{new Date(data.createdAt).toLocaleDateString()}</div>
                </div>
              </div>
            )
          };
        case 'edit':
          return {
            title: 'Edit User Role',
            icon: 'fas fa-user-cog',
            color: designSystem.colors.warning,
            content: (
              <div>
                <div style={{ marginBottom: designSystem.spacing.md }}>
                  <h6 className="text-muted">Editing User Role</h6>
                  <p className="small text-muted">
                    Change the role for this user. This will affect their permissions and access level.
                  </p>
                </div>

                <div style={{ marginBottom: designSystem.spacing.md }}>
                  <label style={{ 
                    display: 'block', 
                    marginBottom: designSystem.spacing.xs,
                    color: designSystem.colors.gray[600],
                    fontSize: designSystem.typography.fontSize.sm,
                    fontWeight: designSystem.typography.fontWeight.medium
                  }}>User: <strong>{data.first_name} {data.last_name}</strong></label>
                  <p style={{ fontSize: designSystem.typography.fontSize.sm, color: designSystem.colors.gray[500] }}>
                    {data.email} • Current Role: {formatRole(data.role)}
                  </p>
                </div>

                <div style={{ marginBottom: designSystem.spacing.md }}>
                  <label style={{ 
                    display: 'block', 
                    marginBottom: designSystem.spacing.xs,
                    color: designSystem.colors.gray[600],
                    fontSize: designSystem.typography.fontSize.sm,
                    fontWeight: designSystem.typography.fontWeight.medium
                  }}>New Role <span className="text-danger">*</span></label>
                  <select 
                    value={formData.role || data.role}
                    onChange={(e) => setFormData(prev => ({ ...prev, role: e.target.value }))}
                    style={componentStyles.formInput}
                    required
                  >
                    <option value="lead_manager">Lead Manager</option>
                    <option value="crm_manager">CRM Manager</option>
                    <option value="project_manager">Project Manager</option>
                    <option value="employee">Employee</option>
                  </select>
                </div>

                <div className="alert alert-warning">
                  <i className="fas fa-exclamation-triangle me-2"></i>
                  <strong>Important:</strong> Changing a user's role will immediately affect their access permissions and dashboard view.
                </div>
              </div>
            )
          };
        case 'delete':
          return {
            title: 'Delete User',
            icon: 'fas fa-trash',
            color: designSystem.colors.danger,
            content: (
              <div>
                <div style={{ marginBottom: designSystem.spacing.md }}>
                  <h6 className="text-danger">Confirm User Deletion</h6>
                  <p className="small text-muted">
                    This will move the user to the deleted section where they can be restored if needed.
                  </p>
                </div>

                <div style={{ marginBottom: designSystem.spacing.md }}>
                  <label style={{ 
                    display: 'block', 
                    marginBottom: designSystem.spacing.xs,
                    color: designSystem.colors.gray[600],
                    fontSize: designSystem.typography.fontSize.sm,
                    fontWeight: designSystem.typography.fontWeight.medium
                  }}>User to Delete:</label>
                  <div style={{
                    padding: designSystem.spacing.md,
                    background: designSystem.colors.gray[50],
                    borderRadius: designSystem.borderRadius.button,
                    border: `1px solid ${designSystem.colors.gray[200]}`
                  }}>
                    <strong>{data.user.first_name} {data.user.last_name}</strong><br/>
                    <small className="text-muted">{data.userEmail} • {formatRole(data.user.role)}</small>
                  </div>
                </div>

                <div className="alert alert-warning">
                  <i className="fas fa-info-circle me-2"></i>
                  <strong>Note:</strong> The user will be moved to the deleted section and can be restored later if needed. The user will lose access to the system immediately.
                </div>
              </div>
            )
          };
        default:
          return { title: '', icon: '', color: '', content: null };
      }
    };

    const config = getModalConfig();

    return (
      <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
        <div className="modal-dialog modal-lg">
          <div className="modal-content">
            <div className="modal-header" style={{ background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
              <h5 className="modal-title">
                <i className={`${config.icon} me-2`}></i>
                {config.title}
              </h5>
              <button 
                type="button" 
                className="btn-close btn-close-white" 
                onClick={onHide}
              ></button>
            </div>
            <div className="modal-body">
              {config.content}
            </div>
            <div className="modal-footer">
              {type === 'edit' ? (
                <>
                  <button 
                    type="button" 
                    className="btn btn-secondary" 
                    onClick={onHide}
                  >
                    Cancel
                  </button>
                  <button 
                    type="button" 
                    className="btn btn-warning" 
                    onClick={() => handleEditUser(data._id, formData.role || data.role)}
                  >
                    <i className="fas fa-save me-1"></i>
                    Update Role
                  </button>
                </>
              ) : type === 'delete' ? (
                <>
                  <button 
                    type="button" 
                    className="btn btn-secondary" 
                    onClick={onHide}
                  >
                    Cancel
                  </button>
                  <button 
                    type="button" 
                    className="btn btn-danger" 
                    onClick={() => handleDeleteUser(data.user._id)}
                  >
                    <i className="fas fa-trash me-1"></i>
                    Delete User
                  </button>
                </>
              ) : (
                <button 
                  type="button" 
                  className="btn btn-primary" 
                  onClick={onHide}
                >
                  Close
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderUserTable = (userType) => {
    const filteredUsers = getFilteredUsers(userType);
    
    if (filteredUsers.length === 0) {
      return (
        <div style={componentStyles.emptyState}>
          <i className="fas fa-users fa-3x" style={{ color: designSystem.colors.gray[400], marginBottom: designSystem.spacing.md }}></i>
          <p style={{ color: designSystem.colors.gray[500], marginBottom: designSystem.spacing.md }}>
            No {userType} found in the system
          </p>
        </div>
      );
    }

    return (
      <div style={{ borderRadius: designSystem.borderRadius.button, overflow: 'hidden', boxShadow: designSystem.shadows.card }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead style={componentStyles.tableHeader}>
            <tr>
              <th style={componentStyles.tableHeaderCell}>User ID</th>
              <th style={componentStyles.tableHeaderCell}>Name</th>
              <th style={componentStyles.tableHeaderCell}>Email</th>
              {userType !== 'admins' && <th style={componentStyles.tableHeaderCell}>Phone</th>}
              <th style={componentStyles.tableHeaderCell}>Role</th>
              <th style={componentStyles.tableHeaderCell}>Status</th>
              <th style={componentStyles.tableHeaderCell}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredUsers.map(user => {
              const isAdmin = user.role === 'admin';
              const statusStyle = getStatusBadgeStyle(user.status || 'active');
              const roleBadgeStyle = getRoleBadgeStyle(user.role);
              
              return (
                <tr 
                  key={user._id}
                  style={componentStyles.tableRow}
                  {...hoverEffects.tableRow}
                >
                  <td style={componentStyles.tableCell}>
                    <span 
                      style={{
                        ...componentStyles.badge,
                        background: designSystem.colors.gray[100],
                        color: designSystem.colors.gray[600],
                        fontFamily: 'monospace'
                      }}
                    >
                      {user._id.slice(-6).toUpperCase()}
                    </span>
                  </td>
                  <td style={componentStyles.tableCell}>
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                      <div 
                        style={{
                          width: '40px',
                          height: '40px',
                          borderRadius: designSystem.borderRadius.button,
                          background: designSystem.colors.primary,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          color: 'white',
                          fontSize: designSystem.typography.fontSize.base,
                          fontWeight: designSystem.typography.fontWeight.semibold,
                          marginRight: designSystem.spacing.sm,
                          boxShadow: designSystem.shadows.button
                        }}
                      >
                        {user.first_name.charAt(0)}{user.last_name.charAt(0)}
                      </div>
                      <div>
                        <div style={{ 
                          color: designSystem.colors.dark, 
                          fontSize: designSystem.typography.fontSize.base,
                          fontWeight: designSystem.typography.fontWeight.medium
                        }}>
                          {`${user.first_name} ${user.last_name}`}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td style={componentStyles.tableCell}>{user.email}</td>
                  {userType !== 'admins' && <td style={componentStyles.tableCell}>{user.phone || '-'}</td>}
                  <td style={componentStyles.tableCell}>
                    <span style={{
                      ...componentStyles.badge,
                      background: roleBadgeStyle.background,
                      color: roleBadgeStyle.color,
                      fontWeight: designSystem.typography.fontWeight.semibold
                    }}>
                      {formatRole(user.role)}
                    </span>
                  </td>
                  <td style={componentStyles.tableCell}>
                    <span style={{
                      ...componentStyles.badge,
                      background: statusStyle.background,
                      color: statusStyle.color
                    }}>
                      {formatStatus(user.status || 'active')}
                    </span>
                  </td>
                  <td style={componentStyles.tableCell}>
                    {isAdmin ? (
                      <span style={{ color: designSystem.colors.gray[500], fontSize: designSystem.typography.fontSize.sm }}>
                        <i className="fas fa-shield-alt"></i> Protected
                      </span>
                    ) : (
                      <div style={{ display: 'flex', gap: designSystem.spacing.xs }}>
                        <button 
                          className="btn btn-outline-primary btn-sm"
                          onClick={() => viewUserDetails(user)}
                          title="View Details"
                        >
                          <i className="fas fa-eye"></i>
                        </button>
                        <button 
                          className="btn btn-outline-warning btn-sm"
                          onClick={() => editUser(user._id)}
                          title="Edit Role"
                        >
                          <i className="fas fa-user-cog"></i>
                        </button>
                        <button 
                          className={`btn btn-sm ${(user.status === 'active' || !user.status) ? 'btn-outline-secondary' : 'btn-outline-success'}`}
                          onClick={() => toggleUserStatus(user)}
                          title={(user.status === 'active' || !user.status) ? 'Deactivate User' : 'Activate User'}
                        >
                          <i className={`fas ${(user.status === 'active' || !user.status) ? 'fa-pause' : 'fa-play'}`}></i>
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  };

  const StatCard = ({ number, label, borderColor, iconColor }) => (
    <div 
      style={{
        ...componentStyles.contactsStatCard,
        borderColor: borderColor,
        cursor: 'pointer'
      }}
      {...hoverEffects.card}
    >
      <div style={{ 
        fontSize: designSystem.typography.fontSize['2xl'], 
        fontWeight: designSystem.typography.fontWeight.bold,
        marginBottom: '4px',
        color: iconColor
      }}>
        {number}
      </div>
      <small style={{ color: designSystem.colors.gray[500] }}>
        {label}
      </small>
    </div>
  );

  return (
    <div style={componentStyles.managementCard}>
      {/* Header with Stats */}
      <div style={componentStyles.header}>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <div style={componentStyles.headerIcon}>
            <i className="fas fa-users fa-lg"></i>
          </div>
          <div>
            <h4 style={componentStyles.headerTitle}>User Management</h4>
            <p style={componentStyles.headerSubtitle}>Manage system users and their roles</p>
          </div>
        </div>
        <button 
          style={{
            ...componentStyles.primaryButton,
            background: designSystem.colors.success
          }}
          onClick={loadUserManagement}
          {...hoverEffects.button}
        >
          <i className="fas fa-sync-alt me-2"></i>Refresh
        </button>
      </div>
      
      {/* Enhanced Overview Stats */}
      <div style={componentStyles.statsContainer}>
        <StatCard 
          number={getUserCounts().clients}
          label="Clients"
          borderColor="#10b981"
          iconColor="#10b981"
        />
        <StatCard 
          number={getUserCounts().managers}
          label="Managers"
          borderColor="#f59e0b"
          iconColor="#f59e0b"
        />
        <StatCard 
          number={getUserCounts().employees}
          label="Employees"
          borderColor="#20c997"
          iconColor="#20c997"
        />
        <StatCard 
          number={getUserCounts().admins}
          label="Admins"
          borderColor="#dc3545"
          iconColor="#dc3545"
        />
        <StatCard 
          number={getUserCounts().inactive}
          label="Inactive Users"
          borderColor="#6c757d"
          iconColor="#6c757d"
        />
      </div>

      {/* Loading State */}
      {loading && (
        <div style={componentStyles.loading}>
          <i className="fas fa-spinner fa-spin fa-2x" style={{ color: designSystem.colors.primary.split(' ')[0].split('(')[1] }}></i>
          <p style={{ marginTop: designSystem.spacing.md, color: designSystem.colors.gray[500] }}>Loading users...</p>
        </div>
      )}

      {/* User Type Tabs */}
      {!loading && (
        <>
          {/* Enhanced User Type Tabs */}
          <div style={{ marginBottom: designSystem.spacing.lg }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ display: 'flex', gap: designSystem.spacing.xs, flexWrap: 'wrap' }}>
                <button 
                  style={{
                    ...componentStyles.primaryButton,
                    background: activeTab === 'clients' ? '#10b981' : designSystem.colors.gray[100],
                    color: activeTab === 'clients' ? 'white' : designSystem.colors.gray[600],
                    boxShadow: activeTab === 'clients' ? designSystem.shadows.button : 'none'
                  }}
                  onClick={() => setActiveTab('clients')}
                  {...hoverEffects.button}
                >
                  Clients ({getUserCounts().clients})
                </button>
                <button 
                  style={{
                    ...componentStyles.primaryButton,
                    background: activeTab === 'managers' ? '#f59e0b' : designSystem.colors.gray[100],
                    color: activeTab === 'managers' ? 'white' : designSystem.colors.gray[600],
                    boxShadow: activeTab === 'managers' ? designSystem.shadows.button : 'none'
                  }}
                  onClick={() => setActiveTab('managers')}
                  {...hoverEffects.button}
                >
                  Managers ({getUserCounts().managers})
                </button>
                <button 
                  style={{
                    ...componentStyles.primaryButton,
                    background: activeTab === 'employees' ? '#20c997' : designSystem.colors.gray[100],
                    color: activeTab === 'employees' ? 'white' : designSystem.colors.gray[600],
                    boxShadow: activeTab === 'employees' ? designSystem.shadows.button : 'none'
                  }}
                  onClick={() => setActiveTab('employees')}
                  {...hoverEffects.button}
                >
                  Employees ({getUserCounts().employees})
                </button>
                <button 
                  style={{
                    ...componentStyles.primaryButton,
                    background: activeTab === 'admins' ? '#dc3545' : designSystem.colors.gray[100],
                    color: activeTab === 'admins' ? 'white' : designSystem.colors.gray[600],
                    boxShadow: activeTab === 'admins' ? designSystem.shadows.button : 'none'
                  }}
                  onClick={() => setActiveTab('admins')}
                  {...hoverEffects.button}
                >
                  Admins ({getUserCounts().admins})
                </button>
                <button 
                  style={{
                    ...componentStyles.primaryButton,
                    background: activeTab === 'inactive' ? '#6c757d' : designSystem.colors.gray[100],
                    color: activeTab === 'inactive' ? 'white' : designSystem.colors.gray[600],
                    boxShadow: activeTab === 'inactive' ? designSystem.shadows.button : 'none'
                  }}
                  onClick={() => setActiveTab('inactive')}
                  {...hoverEffects.button}
                >
                  Inactive ({getUserCounts().inactive})
                </button>
              </div>
              <button 
                style={{
                  ...componentStyles.primaryButton,
                  background: designSystem.colors.primary,
                  fontSize: designSystem.typography.fontSize.base,
                  padding: `${designSystem.spacing.sm} ${designSystem.spacing.lg}`
                }}
                onClick={() => setShowAddModal(true)}
                {...hoverEffects.button}
              >
                <i className="fas fa-plus me-2"></i>Add User
              </button>
            </div>
          </div>

          {/* Tab Content */}
          <div>
            {renderUserTable(activeTab)}
          </div>
        </>
      )}

      {/* No Users Message */}
      {!loading && users.length === 0 && (
        <div style={componentStyles.emptyState}>
          <i className="fas fa-users fa-4x" style={{ color: designSystem.colors.gray[400], marginBottom: designSystem.spacing.lg }}></i>
          <h6 style={{ color: designSystem.colors.gray[500], marginBottom: designSystem.spacing.md }}>No users found in the system</h6>
          <p style={{ color: designSystem.colors.gray[500], marginBottom: designSystem.spacing.lg }}>Get started by adding your first user to the platform</p>
        </div>
      )}

      {/* Add User Modal */}
      {showAddModal && (
        <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <div className="modal-header" style={{ background: 'linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%)', color: 'white' }}>
                <h5 className="modal-title">
                  <i className="fas fa-user-plus me-2"></i>
                  Add New User
                </h5>
                <button 
                  type="button" 
                  className="btn-close btn-close-white" 
                  onClick={() => setShowAddModal(false)}
                ></button>
              </div>
              <div className="modal-body">
                <div style={{ marginBottom: designSystem.spacing.md }}>
                  <h6 style={{ color: designSystem.colors.primary, marginBottom: designSystem.spacing.sm }}>
                    <i className="fas fa-info-circle me-2"></i>Add New User Section
                  </h6>
                  <p style={{ fontSize: designSystem.typography.fontSize.sm, color: designSystem.colors.gray[500] }}>
                    Create a new user account with appropriate role and permissions.
                  </p>
                </div>

                <form onSubmit={handleAddUser}>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: designSystem.spacing.lg }}>
                    <div>
                      <label style={{ 
                        display: 'block', 
                        marginBottom: designSystem.spacing.xs,
                        color: designSystem.colors.gray[600],
                        fontSize: designSystem.typography.fontSize.sm,
                        fontWeight: designSystem.typography.fontWeight.bold
                      }}>
                        First Name <span style={{ color: designSystem.colors.danger.split(' ')[0].split('(')[1] }}>*</span>
                      </label>
                      <input 
                        type="text" 
                        name="first_name"
                        value={formData.first_name}
                        onChange={handleInputChange}
                        placeholder="First Name"
                        style={{
                          ...componentStyles.formInput,
                          borderColor: formErrors.first_name ? designSystem.colors.danger.split(' ')[0].split('(')[1] : componentStyles.formInput.borderColor
                        }}
                        required 
                      />
                      {formErrors.first_name && (
                        <small style={{ color: designSystem.colors.danger.split(' ')[0].split('(')[1], fontSize: designSystem.typography.fontSize.xs }}>
                          {formErrors.first_name}
                        </small>
                      )}
                    </div>
                    <div>
                      <label style={{ 
                        display: 'block', 
                        marginBottom: designSystem.spacing.xs,
                        color: designSystem.colors.gray[600],
                        fontSize: designSystem.typography.fontSize.sm,
                        fontWeight: designSystem.typography.fontWeight.bold
                      }}>
                        Last Name <span style={{ color: designSystem.colors.danger.split(' ')[0].split('(')[1] }}>*</span>
                      </label>
                      <input 
                        type="text" 
                        name="last_name"
                        value={formData.last_name}
                        onChange={handleInputChange}
                        placeholder="Last Name"
                        style={{
                          ...componentStyles.formInput,
                          borderColor: formErrors.last_name ? designSystem.colors.danger.split(' ')[0].split('(')[1] : componentStyles.formInput.borderColor
                        }}
                        required 
                      />
                      {formErrors.last_name && (
                        <small style={{ color: designSystem.colors.danger.split(' ')[0].split('(')[1], fontSize: designSystem.typography.fontSize.xs }}>
                          {formErrors.last_name}
                        </small>
                      )}
                    </div>
                  </div>
                  
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: designSystem.spacing.lg, marginTop: designSystem.spacing.lg }}>
                    <div>
                      <label style={{ 
                        display: 'block', 
                        marginBottom: designSystem.spacing.xs,
                        color: designSystem.colors.gray[600],
                        fontSize: designSystem.typography.fontSize.sm,
                        fontWeight: designSystem.typography.fontWeight.bold
                      }}>
                        Email Address <span style={{ color: '#dc3545' }}>*</span>
                      </label>
                      <input 
                        type="email" 
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="Email Address"
                        style={{
                          ...componentStyles.formInput,
                          borderColor: formErrors.email ? '#dc3545' : componentStyles.formInput.borderColor
                        }}
                        required 
                      />
                      {formErrors.email && (
                        <small style={{ 
                          display: 'block',
                          color: '#dc3545', 
                          fontSize: designSystem.typography.fontSize.xs,
                          marginTop: '4px'
                        }}>
                          {formErrors.email}
                        </small>
                      )}
                      {formData.email && (
                        <div style={{ marginTop: designSystem.spacing.xs }}>
                          <small style={{ fontSize: designSystem.typography.fontSize.xs, color: designSystem.colors.gray[500] }}>
                            Email Requirements:
                          </small>
                          <div style={{ marginTop: '2px' }}>
                            {(() => {
                              const hasAtSymbol = formData.email.includes('@');
                              const parts = formData.email.split('@');
                              const hasTextBeforeAt = parts[0] && parts[0].length > 0;
                              const hasDomainAfterAt = parts.length > 1 && parts[1].length > 0;
                              const hasDotCom = formData.email.toLowerCase().includes('.com');
                              const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                              const isValidFormat = emailRegex.test(formData.email);
                              
                              return (
                                <div style={{ display: 'flex', flexDirection: 'column', gap: '1px' }}>
                                  <small style={{ 
                                    fontSize: '10px', 
                                    color: hasAtSymbol ? '#28a745' : '#dc3545'
                                  }}>
                                    <i className={`fas ${hasAtSymbol ? 'fa-check' : 'fa-times'} me-1`}></i>
                                    Must contain @ symbol
                                  </small>
                                  <small style={{ 
                                    fontSize: '10px', 
                                    color: hasTextBeforeAt ? '#28a745' : '#dc3545'
                                  }}>
                                    <i className={`fas ${hasTextBeforeAt ? 'fa-check' : 'fa-times'} me-1`}></i>
                                    Must have text before @
                                  </small>
                                  <small style={{ 
                                    fontSize: '10px', 
                                    color: hasDomainAfterAt ? '#28a745' : '#dc3545'
                                  }}>
                                    <i className={`fas ${hasDomainAfterAt ? 'fa-check' : 'fa-times'} me-1`}></i>
                                    Must have domain after @
                                  </small>
                                  <small style={{ 
                                    fontSize: '10px', 
                                    color: hasDotCom ? '#28a745' : '#dc3545'
                                  }}>
                                    <i className={`fas ${hasDotCom ? 'fa-check' : 'fa-times'} me-1`}></i>
                                    Must contain .com domain
                                  </small>
                                  <small style={{ 
                                    fontSize: '10px', 
                                    color: isValidFormat ? '#28a745' : '#dc3545'
                                  }}>
                                    <i className={`fas ${isValidFormat ? 'fa-check' : 'fa-times'} me-1`}></i>
                                    Valid email format
                                  </small>
                                </div>
                              );
                            })()}
                          </div>
                        </div>
                      )}
                    </div>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', marginBottom: designSystem.spacing.xs }}>
                        <label style={{ 
                          display: 'block', 
                          color: designSystem.colors.gray[600],
                          fontSize: designSystem.typography.fontSize.sm,
                          fontWeight: designSystem.typography.fontWeight.bold,
                          margin: 0
                        }}>
                          Password <span style={{ color: designSystem.colors.danger.split(' ')[0].split('(')[1] }}>*</span>
                        </label>
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          style={{
                            background: 'none',
                            border: 'none',
                            cursor: 'pointer',
                            color: designSystem.colors.gray[500],
                            padding: '4px 8px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            transition: 'color 0.2s ease',
                            marginLeft: '8px'
                          }}
                          onMouseEnter={(e) => e.currentTarget.style.color = designSystem.colors.primary}
                          onMouseLeave={(e) => e.currentTarget.style.color = designSystem.colors.gray[500]}
                          title={showPassword ? "Hide password" : "Show password"}
                        >
                          <i className={`fas ${showPassword ? 'fa-eye-slash' : 'fa-eye'}`} style={{ fontSize: '16px' }}></i>
                        </button>
                      </div>
                      <input 
                        type={showPassword ? "text" : "password"}
                        name="password"
                        value={formData.password}
                        onChange={handleInputChange}
                        placeholder="Password"
                        maxLength="20"
                        style={{
                          ...componentStyles.formInput,
                          borderColor: formErrors.password ? designSystem.colors.danger.split(' ')[0].split('(')[1] : componentStyles.formInput.borderColor
                        }}
                        required 
                      />
                      {formErrors.password && (
                        <small style={{ color: designSystem.colors.danger.split(' ')[0].split('(')[1], fontSize: designSystem.typography.fontSize.xs }}>
                          {formErrors.password}
                        </small>
                      )}
                      {formData.password && (
                        <div style={{ marginTop: designSystem.spacing.xs }}>
                          <small style={{ fontSize: designSystem.typography.fontSize.xs, color: designSystem.colors.gray[500] }}>
                            Password Requirements:
                          </small>
                          <div style={{ marginTop: '2px' }}>
                            {(() => {
                              const validation = validatePassword(formData.password);
                              const hasMinLength = formData.password.length >= 8;
                              const hasUpperCase = /[A-Z]/.test(formData.password);
                              const hasLowerCase = /[a-z]/.test(formData.password);
                              const hasNumbers = /\d/.test(formData.password);
                              const hasSpecialChar = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~`]/.test(formData.password);
                              
                              return (
                                <div style={{ display: 'flex', flexDirection: 'column', gap: '1px' }}>
                                  <small style={{ 
                                    fontSize: '10px', 
                                    color: hasMinLength ? designSystem.colors.success : designSystem.colors.danger.split(' ')[0].split('(')[1]
                                  }}>
                                    <i className={`fas ${hasMinLength ? 'fa-check' : 'fa-times'} me-1`}></i>
                                    At least 8 characters
                                  </small>
                                  <small style={{ 
                                    fontSize: '10px', 
                                    color: hasUpperCase ? designSystem.colors.success : designSystem.colors.danger.split(' ')[0].split('(')[1]
                                  }}>
                                    <i className={`fas ${hasUpperCase ? 'fa-check' : 'fa-times'} me-1`}></i>
                                    One uppercase letter
                                  </small>
                                  <small style={{ 
                                    fontSize: '10px', 
                                    color: hasLowerCase ? designSystem.colors.success : designSystem.colors.danger.split(' ')[0].split('(')[1]
                                  }}>
                                    <i className={`fas ${hasLowerCase ? 'fa-check' : 'fa-times'} me-1`}></i>
                                    One lowercase letter
                                  </small>
                                  <small style={{ 
                                    fontSize: '10px', 
                                    color: hasNumbers ? designSystem.colors.success : designSystem.colors.danger.split(' ')[0].split('(')[1]
                                  }}>
                                    <i className={`fas ${hasNumbers ? 'fa-check' : 'fa-times'} me-1`}></i>
                                    One number
                                  </small>
                                  <small style={{ 
                                    fontSize: '10px', 
                                    color: hasSpecialChar ? designSystem.colors.success : designSystem.colors.danger.split(' ')[0].split('(')[1]
                                  }}>
                                    <i className={`fas ${hasSpecialChar ? 'fa-check' : 'fa-times'} me-1`}></i>
                                    One special character
                                  </small>
                                </div>
                              );
                            })()}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: designSystem.spacing.lg, marginTop: designSystem.spacing.lg }}>
                    <div>
                      <label style={{ 
                        display: 'block', 
                        marginBottom: designSystem.spacing.xs,
                        color: designSystem.colors.gray[600],
                        fontSize: designSystem.typography.fontSize.sm,
                        fontWeight: designSystem.typography.fontWeight.bold
                      }}>
                        User Role <span style={{ color: designSystem.colors.danger.split(' ')[0].split('(')[1] }}>*</span>
                      </label>
                      <select 
                        name="role"
                        value={formData.role}
                        onChange={handleInputChange}
                        style={{
                          ...componentStyles.formInput,
                          borderColor: formErrors.role ? designSystem.colors.danger.split(' ')[0].split('(')[1] : componentStyles.formInput.borderColor
                        }}
                        required
                      >
                        <option value="">Select Role</option>
                        <option value="lead_manager">Lead Manager</option>
                        <option value="crm_manager">CRM Manager</option>
                        <option value="project_manager">Project Manager</option>
                        <option value="employee">Employee</option>
                      </select>
                      {formErrors.role && (
                        <small style={{ color: designSystem.colors.danger.split(' ')[0].split('(')[1], fontSize: designSystem.typography.fontSize.xs }}>
                          {formErrors.role}
                        </small>
                      )}
                      <div style={{ 
                        marginTop: designSystem.spacing.xs,
                        fontSize: designSystem.typography.fontSize.xs,
                        color: designSystem.colors.gray[500]
                      }}>
                        Choose the appropriate role for this user
                      </div>
                    </div>
                    <div>
                      <label style={{ 
                        display: 'block', 
                        marginBottom: designSystem.spacing.xs,
                        color: designSystem.colors.gray[600],
                        fontSize: designSystem.typography.fontSize.sm,
                        fontWeight: designSystem.typography.fontWeight.bold
                      }}>
                        Phone Number
                      </label>
                      <input 
                        type="tel" 
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        placeholder="Phone Number (10 digits)"
                        maxLength={10}
                        style={{
                          ...componentStyles.formInput,
                          borderColor: formErrors.phone ? '#dc3545' : componentStyles.formInput.borderColor
                        }}
                      />
                      {formErrors.phone && (
                        <small style={{ 
                          display: 'block',
                          color: '#dc3545', 
                          fontSize: designSystem.typography.fontSize.xs,
                          marginTop: '4px'
                        }}>
                          {formErrors.phone}
                        </small>
                      )}
                      {formData.phone && (
                        <div style={{ marginTop: designSystem.spacing.xs }}>
                          <small style={{ fontSize: designSystem.typography.fontSize.xs, color: designSystem.colors.gray[500] }}>
                            Phone Requirements:
                          </small>
                          <div style={{ marginTop: '2px' }}>
                            {(() => {
                              const digitsOnly = formData.phone.replace(/\D/g, '');
                              const hasExactly10Digits = digitsOnly.length === 10;
                              const startsWithValid = digitsOnly.length > 0 && /^[2-9]/.test(digitsOnly);
                              const isAllDigits = /^\d+$/.test(digitsOnly);
                              
                              return (
                                <div style={{ display: 'flex', flexDirection: 'column', gap: '1px' }}>
                                  <small style={{ 
                                    fontSize: '10px', 
                                    color: hasExactly10Digits ? '#28a745' : '#dc3545'
                                  }}>
                                    <i className={`fas ${hasExactly10Digits ? 'fa-check' : 'fa-times'} me-1`}></i>
                                    Must be exactly 10 digits
                                  </small>
                                  <small style={{ 
                                    fontSize: '10px', 
                                    color: startsWithValid ? '#28a745' : '#dc3545'
                                  }}>
                                    <i className={`fas ${startsWithValid ? 'fa-check' : 'fa-times'} me-1`}></i>
                                    Must start with 2-9
                                  </small>
                                  <small style={{ 
                                    fontSize: '10px', 
                                    color: isAllDigits ? '#28a745' : '#dc3545'
                                  }}>
                                    <i className={`fas ${isAllDigits ? 'fa-check' : 'fa-times'} me-1`}></i>
                                    Only numbers allowed
                                  </small>
                                </div>
                              );
                            })()}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: designSystem.spacing.lg, marginTop: designSystem.spacing.lg }}>
                    <div>
                      <label style={{ 
                        display: 'block', 
                        marginBottom: designSystem.spacing.xs,
                        color: designSystem.colors.gray[600],
                        fontSize: designSystem.typography.fontSize.sm,
                        fontWeight: designSystem.typography.fontWeight.bold
                      }}>
                        Company
                      </label>
                      <input 
                        type="text" 
                        name="company"
                        value={formData.company}
                        onChange={handleInputChange}
                        placeholder="Company"
                        style={componentStyles.formInput}
                      />
                    </div>
                    <div>
                      <label style={{ 
                        display: 'block', 
                        marginBottom: designSystem.spacing.xs,
                        color: designSystem.colors.gray[600],
                        fontSize: designSystem.typography.fontSize.sm,
                        fontWeight: designSystem.typography.fontWeight.bold
                      }}>
                        Country
                      </label>
                      <input 
                        type="text" 
                        name="country"
                        value={formData.country}
                        onChange={handleInputChange}
                        placeholder="Country"
                        style={componentStyles.formInput}
                      />
                    </div>
                  </div>
                </form>
              </div>
              <div className="modal-footer">
                
                <button 
                  type="button" 
                  className="btn btn-primary"
                  onClick={handleAddUser}
                >
                  <i className="fas fa-save me-1"></i>
                  Create User
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Unified Modal */}
      <UnifiedModal
        show={showModal}
        onHide={handleModalClose}
        type={modalType}
        data={modalData}
      />
    </div>
  );
};

export default UserManagement;