const express = require('express');
const { body } = require('express-validator');
const rateLimit = require('express-rate-limit');
const { auth } = require('../middleware/auth');
const {
  subscribe,
  unsubscribe,
  getAllSubscribers,
  getSubscriberCount
} = require('../controllers/newsletterController');

const router = express.Router();

// Rate limiting for public endpoints
const publicRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // Limit each IP to 5 subscription attempts per windowMs
  message: {
    success: false,
    error: {
      code: 'RATE_LIMIT_EXCEEDED',
      message: 'Too many subscription attempts. Please try again later.'
    }
  }
});

// Validation for subscription
const validateSubscription = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address')
];

// Validation for unsubscription
const validateUnsubscription = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address')
];

// Public Routes

// @route   POST /api/newsletter/subscribe
// @desc    Subscribe to newsletter
// @access  Public
router.post('/subscribe', 
  publicRateLimit,
  validateSubscription,
  subscribe
);

// @route   POST /api/newsletter/unsubscribe
// @desc    Unsubscribe from newsletter
// @access  Public
router.post('/unsubscribe', 
  validateUnsubscription,
  unsubscribe
);

// Private Routes (Admin only)

// @route   GET /api/newsletter/subscribers
// @desc    Get all newsletter subscribers
// @access  Private (Admin)
router.get('/subscribers', 
  auth(['admin']),
  getAllSubscribers
);

// @route   GET /api/newsletter/count
// @desc    Get subscriber count statistics
// @access  Private (Admin)
router.get('/count', 
  auth(['admin']),
  getSubscriberCount
);

module.exports = router;
