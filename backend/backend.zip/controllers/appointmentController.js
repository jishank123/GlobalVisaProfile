const AppointmentRequest = require('../models/AppointmentRequest');
const ActivityLog = require('../models/ActivityLog');
const clientService = require('../services/clientService');
const EncryptionManager = require('../utils/encryptionManager');
const { validationResult } = require('express-validator');

/**
 * Appointment Controller
 * Handles consultation appointment booking with comprehensive security
 */

// @desc    Submit Appointment Request
// @route   POST /api/appointments
// @access  Public (with rate limiting and validation)
const submitAppointmentRequest = async (req, res) => {
  try {
    console.log('📅 === APPOINTMENT SUBMISSION REQUEST ===');
    console.log('📅 User:', req.user?.email || 'Anonymous', 'Role:', req.user?.role || 'Public');
    console.log('📅 Request body:', JSON.stringify(req.body, null, 2));

    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      console.log('❌ Validation errors:', errors.array());
      return res.status(400).json({
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Invalid input data',
          details: errors.array(),
          validationErrors: errors.array().map(err => `${err.param}: ${err.msg}`)
        }
      });
    }

    const {
      name,
      email,
      phone,
      visa_category,
      timezone,
      preferred_date,
      preferred_time,
      consultation_type,
      details,
      status,
      priority,
      assigned_to,
      created_by,
      scheduled_date,
      scheduled_time,
      duration_minutes,
      meeting_link,
      consultation_notes
    } = req.body;

    // Determine if this is created by an authenticated user (lead manager)
    const isCreatedByLeadManager = req.user && req.user.role === 'lead_manager';
    const isCreatedByCrmManager = req.user && req.user.role === 'crm_manager';
    const isCreatedByStaff = isCreatedByLeadManager || isCreatedByCrmManager || (req.user && req.user.role === 'admin');

    console.log('🔍 Appointment creation context:', {
      hasUser: !!req.user,
      userRole: req.user?.role,
      userEmail: req.user?.email,
      isCreatedByLeadManager,
      isCreatedByStaff
    });

    // Use deferred encryption for the entire process
    const result = await EncryptionManager.bulkOperationWithDeferredEncryption(async () => {
      // Check for duplicate recent submissions (prevent spam) - only for public submissions
      if (!isCreatedByStaff) {
        const recentSubmission = await AppointmentRequest.findOne({
          email: email.toLowerCase(),
          createdAt: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } // Last 24 hours
        });

        if (recentSubmission) {
          console.log('❌ Duplicate submission detected for:', email);
          return { error: 'DUPLICATE_SUBMISSION' };
        }
      }

      // Create appointment request (without encryption)
      const appointment = new AppointmentRequest({
        name: name.trim(),
        email: email.toLowerCase().trim(),
        phone: phone.trim(),
        visa_category,
        timezone,
        preferred_date: preferred_date?.trim(),
        preferred_time: preferred_time?.trim(),
        consultation_type: consultation_type || 'video',
        details: details?.trim(),
        status: status || 'pending',
        priority: priority || 'medium',
        assigned_to: assigned_to || null,
        created_by: isCreatedByStaff ? (created_by || req.user._id) : null,
        scheduled_date: scheduled_date ? new Date(scheduled_date) : null,
        scheduled_time: scheduled_time || null,
        duration_minutes: duration_minutes || 30,
        meeting_link: meeting_link || null,
        consultation_notes: consultation_notes || null,
        ip_address: req.ip,
        user_agent: req.get('User-Agent'),
        source: isCreatedByStaff ? 'staff' : 'website'
      });

      const savedAppointment = await appointment.save();
      const documentsToEncrypt = [savedAppointment];

      // Auto-register client account - only for public submissions (without encryption)
      let user = null;
      let client = null;
      if (!isCreatedByStaff) {
        // If client is already logged in, use their user ID directly
        if (req.user && req.user._id) {
          console.log('🔄 Logged-in client submitting appointment, linking user_id directly:', req.user._id);
          savedAppointment.user_id = req.user._id;
          // Also try to find client record
          try {
            const Client = require('../models/Client');
            const clientRecord = await Client.findOne({ user_id: req.user._id });
            if (clientRecord) {
              savedAppointment.client_id = clientRecord._id;
            }
          } catch (e) { /* non-critical */ }
          await savedAppointment.save();
        } else {
          console.log('🔄 Anonymous client submitting appointment, auto-registering...');
          try {
            const autoRegResult = await clientService.createOrGetClient({
              name,
              email,
              phone,
              company: '',
              current_location: ''
            }, 'appointment_request');

            user = autoRegResult.user;
            client = autoRegResult.client;

            // Add to documents to encrypt - only newly created ones
            if (autoRegResult.isNewUser) {
              documentsToEncrypt.push(user);
            }
            if (autoRegResult.isNewClient) {
              documentsToEncrypt.push(client);
            }

            // Link appointment to user (without encryption)
            savedAppointment.user_id = user._id;
            savedAppointment.client_id = client._id;
            await savedAppointment.save();
            
          } catch (autoRegError) {
            console.error('⚠️ Auto-registration failed (non-critical):', autoRegError.message);
          }
        }
      }

      // Log activity for security audit (without encryption)
      try {
        const activityLog = await ActivityLog.create({
          user: req.user?._id || null,
          action: 'create',
          resourceType: 'AppointmentRequest',
          resourceId: savedAppointment._id,
          description: `Appointment request ${isCreatedByStaff ? 'created by staff' : 'submitted'} for ${email}`,
          metadata: {
            email,
            visa_category,
            consultation_type,
            timezone,
            preferred_date,
            preferred_time,
            created_by_staff: isCreatedByStaff,
            staff_role: req.user?.role
          },
          ipAddress: req.ip,
          userAgent: req.get('User-Agent')
        });
        
        documentsToEncrypt.push(activityLog);
      } catch (logError) {
        console.log('⚠️ Activity log creation failed (non-critical):', logError.message);
      }

      return {
        appointment: savedAppointment,
        user,
        client,
        documents: documentsToEncrypt
      };
    });

    // Handle duplicate submission error
    if (result.error === 'DUPLICATE_SUBMISSION') {
      return res.status(429).json({
        success: false,
        error: {
          code: 'DUPLICATE_SUBMISSION',
          message: 'You have already submitted an appointment request in the last 24 hours. Please check your email or contact us directly.'
        }
      });
    }

    // Return success response (excluding sensitive data) - encryption happens in background
    res.status(201).json({
      success: true,
      message: isCreatedByStaff 
        ? 'Appointment created successfully by staff member.' 
        : 'Appointment request submitted successfully. We will contact you within 24 hours to confirm your consultation.',
      data: {
        appointment_id: result.appointment._id,
        name: result.appointment.name,
        email: result.appointment.email,
        visa_category: result.appointment.visa_category_display,
        status: result.appointment.status_display,
        submission_date: result.appointment.createdAt,
        reference_number: `APT-${result.appointment._id.toString().slice(-8).toUpperCase()}`,
        created_by_staff: isCreatedByStaff,
        created_by: result.appointment.created_by,
        source: result.appointment.source
      }
    });

  } catch (error) {
    console.error('❌ Appointment Request Submission Error:', error);
    console.error('❌ Error stack:', error.stack);
    
    // Log error for monitoring
    if (req.body?.email) {
      await ActivityLog.create({
        user: req.user?._id || null,
        action: 'other',
        resourceType: 'System',
        description: `Appointment request submission failed for ${req.body.email}`,
        metadata: { 
          error: error.message,
          errorStack: error.stack,
          created_by_staff: !!(req.user && ['lead_manager', 'crm_manager', 'admin'].includes(req.user.role)),
          requestBody: req.body
        },
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      }).catch(() => {}); // Silent fail for logging
    }

    // Return detailed error for debugging
    res.status(500).json({
      success: false,
      error: {
        code: 'SUBMISSION_ERROR',
        message: process.env.NODE_ENV === 'development' 
          ? `Appointment submission failed: ${error.message}` 
          : 'Failed to submit appointment request. Please try again or contact us directly.',
        details: process.env.NODE_ENV === 'development' ? error.stack : undefined
      }
    });
  }
};

// @desc    Get Appointment Request by ID
// @route   GET /api/appointments/:id
// @access  Private (Admin/Manager only)
const getAppointmentRequest = async (req, res) => {
  try {
    const appointment = await AppointmentRequest.findById(req.params.id)
      .populate('assigned_to', 'first_name last_name email')
      .populate('converted_to_client', 'name email');
    
    if (!appointment) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'NOT_FOUND',
          message: 'Appointment request not found'
        }
      });
    }

    // Log access for audit
    await ActivityLog.create({
      user: req.user._id,
      action: 'view',
      resourceType: 'AppointmentRequest',
      resourceId: appointment._id,
      description: `Appointment request viewed by ${req.user.email}`,
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    res.json({
      success: true,
      data: appointment
    });

  } catch (error) {
    console.error('Get Appointment Request Error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'FETCH_ERROR',
        message: 'Failed to retrieve appointment request'
      }
    });
  }
};

// @desc    Get All Appointment Requests (with pagination and filtering)
// @route   GET /api/appointments
// @access  Private (Admin/Manager/Client)
const getAllAppointmentRequests = async (req, res) => {
  try {
    console.log('📅 === GET ALL APPOINTMENTS REQUEST ===');
    console.log('📅 User:', req.user?.email, 'Role:', req.user?.role);
    console.log('📅 User ID:', req.user?._id);
    
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    // Build filter object
    const filter = {};
    if (req.query.status) filter.status = req.query.status;
    if (req.query.visa_category) filter.visa_category = req.query.visa_category;
    if (req.query.priority) filter.priority = req.query.priority;
    if (req.query.assigned_to) filter.assigned_to = req.query.assigned_to;

    // Role-based filtering
    if (req.user.role === 'lead_manager') {
      // Lead managers can only see appointments they created
      filter.created_by = req.user._id;
    } else if (req.user.role === 'client') {
      // Clients can only see appointments linked to their user ID
      const userId = req.user._id || req.user.user_id || req.user.id;
      filter.$or = [
        { user_id: userId },
        { email: req.user.email.toLowerCase() } // Fallback for older appointments
      ];
      console.log('📅 Client filter applied:', { 
        user_id: userId, 
        email_fallback: req.user.email 
      });
    }

    // Date range filter
    if (req.query.start_date || req.query.end_date) {
      filter.createdAt = {};
      if (req.query.start_date) filter.createdAt.$gte = new Date(req.query.start_date);
      if (req.query.end_date) filter.createdAt.$lte = new Date(req.query.end_date);
    }

    console.log('📅 Final filter:', filter);

    // Get appointments with pagination
    const appointments = await AppointmentRequest.find(filter)
      .populate('assigned_to', 'first_name last_name email')
      .populate('converted_to_client', 'name email')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .select('-ip_address -user_agent'); // Exclude sensitive data

    const total = await AppointmentRequest.countDocuments(filter);

    console.log('📅 Found appointments:', appointments.length, 'Total:', total);
    console.log('📅 Sample appointment:', appointments.length > 0 ? {
      id: appointments[0]._id,
      email: appointments[0].email,
      status: appointments[0].status,
      name: appointments[0].name
    } : 'No appointments found');

    // Log access
    await ActivityLog.create({
      user: req.user._id,
      action: 'view',
      resourceType: 'AppointmentRequest',
      description: `Appointment requests list viewed by ${req.user.email} (${req.user.role})`,
      metadata: { 
        page, 
        limit, 
        total, 
        filter,
        user_role: req.user.role,
        appointments_count: appointments.length
      },
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    res.json({
      success: true,
      data: appointments,
      count: appointments.length,
      total: total,
      page: parseInt(page),
      totalPages: Math.ceil(total / limit),
      pagination: {
        current_page: page,
        total_pages: Math.ceil(total / limit),
        total_records: total,
        per_page: limit
      }
    });

  } catch (error) {
    console.error('❌ Get All Appointment Requests Error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'FETCH_ERROR',
        message: 'Failed to retrieve appointment requests'
      }
    });
  }
};

// @desc    Update Appointment Request Status
// @route   PUT /api/appointments/:id/status
// @access  Private (Admin/Manager only)
const updateAppointmentStatus = async (req, res) => {
  try {
    const { status, assigned_to, consultation_notes, follow_up_required, follow_up_date } = req.body;
    
    const appointment = await AppointmentRequest.findById(req.params.id);
    if (!appointment) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'NOT_FOUND',
          message: 'Appointment request not found'
        }
      });
    }

    const oldStatus = appointment.status;
    appointment.status = status;
    if (assigned_to) appointment.assigned_to = assigned_to;
    if (consultation_notes) appointment.consultation_notes = consultation_notes;
    if (follow_up_required !== undefined) appointment.follow_up_required = follow_up_required;
    if (follow_up_date) appointment.follow_up_date = new Date(follow_up_date);

    await appointment.save();

    // Log status change
    await ActivityLog.create({
      user: req.user._id,
      action: 'update',
      resourceType: 'AppointmentRequest',
      resourceId: appointment._id,
      description: `Appointment status changed from ${oldStatus} to ${status}`,
      metadata: { 
        old_status: oldStatus, 
        new_status: status, 
        assigned_to,
        follow_up_required 
      },
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    res.json({
      success: true,
      message: 'Appointment status updated successfully',
      data: appointment
    });

  } catch (error) {
    console.error('Update Appointment Status Error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'UPDATE_ERROR',
        message: 'Failed to update appointment status'
      }
    });
  }
};

// @desc    Schedule Appointment
// @route   PUT /api/appointments/:id/schedule
// @access  Private (Admin/Manager only)
const scheduleAppointment = async (req, res) => {
  try {
    const { scheduled_date, scheduled_time, duration_minutes, meeting_link, meeting_id, consultation_notes } = req.body;
    
    const appointment = await AppointmentRequest.findById(req.params.id);
    if (!appointment) {
      return res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Appointment request not found' }
      });
    }

    // Build update — bypass validation on encrypted enum fields using { validateBeforeSave: false }
    appointment.scheduled_date = new Date(scheduled_date);
    if (scheduled_time) appointment.scheduled_time = scheduled_time;
    if (meeting_link) appointment.meeting_link = meeting_link;
    if (meeting_id) appointment.meeting_id = meeting_id;
    if (consultation_notes) appointment.consultation_notes = consultation_notes;
    if (duration_minutes) appointment.duration_minutes = duration_minutes;
    appointment.status = 'confirmed';
    appointment.assigned_to = req.user._id;

    await appointment.save({ validateBeforeSave: false });

    // Log scheduling
    await ActivityLog.create({
      user: req.user._id,
      action: 'update',
      resourceType: 'AppointmentRequest',
      resourceId: appointment._id,
      description: `Appointment scheduled for ${scheduled_date} at ${scheduled_time}`,
      metadata: { scheduled_date, scheduled_time, duration_minutes, meeting_link: meeting_link ? 'provided' : 'not_provided' },
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    const updated = await AppointmentRequest.findById(req.params.id);
    res.json({ success: true, message: 'Appointment scheduled successfully', data: updated });

  } catch (error) {
    console.error('Schedule Appointment Error:', error);
    res.status(500).json({
      success: false,
      error: { code: 'SCHEDULE_ERROR', message: error.message || 'Failed to schedule appointment' }
    });
  }
};

// @desc    Add Communication to Appointment
// @route   POST /api/appointments/:id/communications
// @access  Private (Admin/Manager only)
const addCommunication = async (req, res) => {
  try {
    const { type, message, direction } = req.body;
    
    const appointment = await AppointmentRequest.findById(req.params.id);
    if (!appointment) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'NOT_FOUND',
          message: 'Appointment request not found'
        }
      });
    }

    // Use the model method to add communication
    await appointment.addCommunication(type, message, req.user._id, direction);

    // Log communication
    await ActivityLog.create({
      user: req.user._id,
      action: 'update',
      resourceType: 'AppointmentRequest',
      resourceId: appointment._id,
      description: `Communication added: ${type} - ${direction}`,
      metadata: { type, direction, message_length: message.length },
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    res.json({
      success: true,
      message: 'Communication added successfully',
      data: appointment
    });

  } catch (error) {
    console.error('Add Communication Error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'COMMUNICATION_ERROR',
        message: 'Failed to add communication'
      }
    });
  }
};

// @desc    Delete Appointment Request
// @route   DELETE /api/appointments/:id
// @access  Private (Admin only)
const deleteAppointmentRequest = async (req, res) => {
  try {
    const appointment = await AppointmentRequest.findById(req.params.id);
    if (!appointment) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'NOT_FOUND',
          message: 'Appointment request not found'
        }
      });
    }

    await AppointmentRequest.findByIdAndDelete(req.params.id);

    // Log deletion
    await ActivityLog.create({
      user: req.user._id,
      action: 'delete',
      resourceType: 'AppointmentRequest',
      resourceId: req.params.id,
      description: `Appointment request deleted by ${req.user.email}`,
      metadata: { 
        client_email: appointment.email,
        visa_category: appointment.visa_category,
        status: appointment.status
      },
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });

    res.json({
      success: true,
      message: 'Appointment request deleted successfully'
    });

  } catch (error) {
    console.error('Delete Appointment Request Error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'DELETE_ERROR',
        message: 'Failed to delete appointment request'
      }
    });
  }
};

// @desc    Get appointments created by current CRM manager
// @route   GET /api/appointments/my-appointments
// @access  Private (CRM Manager only)
const getMyAppointments = async (req, res) => {
  try {
    console.log('📅 === GET MY APPOINTMENTS REQUEST ===');
    console.log('📅 User:', req.user?.email, 'Role:', req.user?.role);
    console.log('📅 User ID:', req.user?._id);
    
    if (req.user.role !== 'crm_manager') {
      return res.status(403).json({
        success: false,
        error: {
          code: 'FORBIDDEN',
          message: 'Only CRM managers can access this endpoint'
        }
      });
    }
    
    const { status, page = 1, limit = 20 } = req.query;
    
    // Build query for appointments created by this CRM manager
    let query = {
      created_by: req.user._id  // Get appointments created by this CRM manager
    };
    
    if (status) query.status = status;
    
    console.log('📅 Query for CRM appointments:', query);
    
    const appointments = await AppointmentRequest.find(query)
      .populate('assigned_to', 'first_name last_name email')
      .sort({ scheduled_date: -1, createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .select('-ip_address -user_agent'); // Exclude sensitive data
    
    const count = await AppointmentRequest.countDocuments(query);
    
    console.log('📅 Found CRM created appointments:', appointments.length, 'Total:', count);
    console.log('📅 Sample appointment:', appointments.length > 0 ? {
      id: appointments[0]._id,
      name: appointments[0].name,
      email: appointments[0].email,
      status: appointments[0].status,
      created_by: appointments[0].created_by,
      scheduled_date: appointments[0].scheduled_date
    } : 'No appointments found');
    
    res.json({
      success: true,
      count: appointments.length,
      total: count,
      page: parseInt(page),
      totalPages: Math.ceil(count / limit),
      data: appointments
    });
  } catch (error) {
    console.error('❌ Get CRM appointments error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'FETCH_CRM_APPOINTMENTS_FAILED',
        message: error.message
      }
    });
  }
};

// @desc    Get appointments for a specific client by email
// @route   GET /api/appointments/client/:email
// @access  Private (Client/Admin/Manager)
const getClientAppointments = async (req, res) => {
  try {
    console.log('\n📅 === GET CLIENT APPOINTMENTS - COMPREHENSIVE SEARCH ===');
    const clientEmail = req.params.email;
    const userRole = req.user.role;
    const userId = req.user._id || req.user.user_id || req.user.id;
    
    console.log('📅 Searching for:', clientEmail);
    console.log('📅 Requested by:', req.user?.email, 'Role:', userRole);
    
    // Security check
    if (userRole === 'client' && req.user.email !== clientEmail) {
      return res.status(403).json({
        success: false,
        error: { code: 'FORBIDDEN', message: 'You can only access your own appointments' }
      });
    }
    
    const { status, page = 1, limit = 100 } = req.query;
    
    // STEP 1: Get User and Client records
    const User = require('../models/User');
    const Client = require('../models/Client');
    
    const targetUser = await User.findOne({ email: clientEmail });
    console.log('📅 User found:', targetUser ? `ID: ${targetUser._id}` : 'NO');
    
    let clientRecord = null;
    if (targetUser) {
      clientRecord = await Client.findOne({ user_id: targetUser._id });
      console.log('📅 Client by user_id:', clientRecord ? `ID: ${clientRecord._id}` : 'NO');
    }
    
    if (!clientRecord) {
      clientRecord = await Client.findOne({ email: clientEmail });
      console.log('📅 Client by email:', clientRecord ? `ID: ${clientRecord._id}` : 'NO');
    }
    
    // STEP 2: Fetch ALL appointments (we'll filter in memory after decryption)
    console.log('📅 Fetching all appointments...');
    const allAppointments = await AppointmentRequest.find({})
      .populate('assigned_to', 'first_name last_name email')
      .sort({ scheduled_date: -1, createdAt: -1 })
      .select('-ip_address -user_agent');
    
    console.log('📅 Total appointments in DB:', allAppointments.length);
    console.log('\n📅 === ALL APPOINTMENTS DETAILS ===');
    allAppointments.forEach((apt, index) => {
      console.log(`\n📅 Appointment ${index + 1}:`);
      console.log('   ID:', apt._id);
      console.log('   Email (decrypted):', apt.email);
      console.log('   Name:', apt.name);
      console.log('   user_id:', apt.user_id);
      console.log('   client_id:', apt.client_id);
      console.log('   Status:', apt.status);
      console.log('   Created by:', apt.created_by);
    });
    console.log('\n📅 === COMPARISON VALUES ===');
    console.log('Looking for email:', clientEmail);
    console.log('Looking for user_id:', targetUser ? targetUser._id.toString() : 'N/A');
    console.log('Looking for client_id:', clientRecord ? clientRecord._id.toString() : 'N/A');
    
    // STEP 3: Filter appointments by ANY matching criteria
    console.log('\n📅 === FILTERING APPOINTMENTS ===');
    const matchingAppointments = allAppointments.filter(apt => {
      console.log(`\n📅 Checking appointment ${apt._id}:`);
      
      // Check 1: Email match (case-insensitive)
      const emailMatch = apt.email && apt.email.toLowerCase() === clientEmail.toLowerCase();
      console.log(`   Email check: "${apt.email}" === "${clientEmail}" ? ${emailMatch}`);
      if (emailMatch) {
        console.log('   ✅ MATCHED BY EMAIL');
        return true;
      }
      
      // Check 2: user_id match
      if (targetUser && apt.user_id) {
        const userIdMatch = apt.user_id.toString() === targetUser._id.toString();
        console.log(`   user_id check: "${apt.user_id}" === "${targetUser._id}" ? ${userIdMatch}`);
        if (userIdMatch) {
          console.log('   ✅ MATCHED BY USER_ID');
          return true;
        }
      } else {
        console.log('   user_id check: SKIPPED (no user_id on appointment or no target user)');
      }
      
      // Check 3: client_id match
      if (clientRecord && apt.client_id) {
        const clientIdMatch = apt.client_id.toString() === clientRecord._id.toString();
        console.log(`   client_id check: "${apt.client_id}" === "${clientRecord._id}" ? ${clientIdMatch}`);
        if (clientIdMatch) {
          console.log('   ✅ MATCHED BY CLIENT_ID');
          return true;
        }
      } else {
        console.log('   client_id check: SKIPPED (no client_id on appointment or no client record)');
      }
      
      console.log('   ❌ NO MATCH');
      return false;
    });
    
    console.log('📅 Matching appointments found:', matchingAppointments.length);
    
    // STEP 4: Apply status filter if provided
    let filteredAppointments = matchingAppointments;
    if (status) {
      filteredAppointments = matchingAppointments.filter(apt => apt.status === status);
      console.log('📅 After status filter:', filteredAppointments.length);
    }
    
    // STEP 5: Apply pagination
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedAppointments = filteredAppointments.slice(startIndex, endIndex);
    
    console.log('📅 ✅ RETURNING:', paginatedAppointments.length, 'appointments');
    if (paginatedAppointments.length > 0) {
      paginatedAppointments.forEach(apt => {
        console.log('📅   -', apt._id, '|', apt.email, '|', apt.status, '|', apt.scheduled_date);
      });
    }
    console.log('📅 === END ===\n');
    
    // Log access for audit
    await ActivityLog.create({
      user: req.user._id || req.user.id,
      action: 'view',
      resourceType: 'AppointmentRequest',
      description: `Client appointments viewed for ${clientEmail}`,
      metadata: { 
        client_email: clientEmail,
        appointments_count: paginatedAppointments.length,
        total_matches: filteredAppointments.length,
        requested_by: req.user.email,
        user_role: req.user.role
      },
      ipAddress: req.ip,
      userAgent: req.get('User-Agent')
    });
    
    res.json({
      success: true,
      count: paginatedAppointments.length,
      total: filteredAppointments.length,
      page: parseInt(page),
      totalPages: Math.ceil(filteredAppointments.length / limit),
      data: paginatedAppointments
    });
    
  } catch (error) {
    console.error('❌ Get client appointments error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'FETCH_CLIENT_APPOINTMENTS_FAILED',
        message: error.message
      }
    });
  }
};

// @desc    Get appointments created by current lead manager
// @route   GET /api/appointments/my-created-appointments
// @access  Private (Lead Manager only)
const getMyCreatedAppointments = async (req, res) => {
  try {
    console.log('📅 === GET MY CREATED APPOINTMENTS REQUEST ===');
    console.log('📅 User:', req.user?.email, 'Role:', req.user?.role);
    
    if (req.user.role !== 'lead_manager') {
      return res.status(403).json({
        success: false,
        error: {
          code: 'FORBIDDEN',
          message: 'Only lead managers can access this endpoint'
        }
      });
    }
    
    const { status, page = 1, limit = 50 } = req.query;
    const leadManagerId = req.user._id;

    // Step 1: Find all leads assigned to this lead manager → get their emails
    const Lead = require('../models/Lead');
    const User = require('../models/User');

    const assignedLeads = await Lead.find({ assignedTo: leadManagerId }).select('email');
    const leadEmails = assignedLeads.map(l => l.email).filter(Boolean);
    console.log('📅 Assigned lead emails:', leadEmails.length);
    console.log('📅 Lead emails sample:', leadEmails.slice(0, 3));

    // Step 2: Find User _ids for those emails (client accounts)
    let clientUserIds = [];
    if (leadEmails.length > 0) {
      // Fetch all users and filter by decrypted email (encryption makes direct query unreliable)
      const allUsers = await User.find({ role: 'client' }).select('_id email');
      console.log('📅 Total client users fetched:', allUsers.length);
      console.log('📅 Sample user emails:', allUsers.slice(0, 3).map(u => u.email));
      clientUserIds = allUsers
        .filter(u => leadEmails.includes((u.email || '').toLowerCase().trim()))
        .map(u => u._id);
      console.log('📅 Matched client user IDs:', clientUserIds.length);
    }

    // Step 3: Also find appointments by matching email directly (fallback for unlinked user_id)
    // Fetch all appointments and filter by email match in memory
    const allAppointments = await AppointmentRequest.find({})
      .populate('assigned_to', 'first_name last_name email')
      .sort({ createdAt: -1 })
      .select('-ip_address -user_agent');

    // Build set of lead emails for fast lookup
    const leadEmailSet = new Set(leadEmails.map(e => e.toLowerCase().trim()));

    console.log('📅 Total appointments in DB:', allAppointments.length);
    console.log('📅 Lead email set:', [...leadEmailSet]);
    console.log('📅 Client user IDs:', clientUserIds.map(id => id.toString()));
    allAppointments.forEach(a => {
      const emailInSet = a.email ? leadEmailSet.has(a.email.toLowerCase().trim()) : false;
      const userIdMatch = a.user_id ? clientUserIds.some(id => id.toString() === a.user_id.toString()) : false;
      console.log(`📅 Appt ${a._id}: email="${a.email}" emailMatch=${emailInSet} user_id="${a.user_id}" userIdMatch=${userIdMatch} created_by="${a.created_by}" status="${a.status}"`);
    });

    // Filter: only appointments belonging to leads assigned to this manager
    // (by user_id match OR email match) — do NOT include created_by to avoid pulling unrelated appointments
    const filteredAppointments = allAppointments.filter(appt => {
      if (clientUserIds.length > 0 && appt.user_id && clientUserIds.some(id => id.toString() === appt.user_id.toString())) return true;
      // Email fallback — appointment email is decrypted by post-find hook
      if (appt.email && leadEmailSet.has(appt.email.toLowerCase().trim())) return true;
      return false;
    });

    console.log('📅 Found lead manager appointments (all sources):', filteredAppointments.length);

    // Apply status filter
    let result = filteredAppointments;
    if (status) result = filteredAppointments.filter(a => a.status === status);

    // Apply pagination in memory
    const total = result.length;
    const skip = (page - 1) * limit;
    const paginated = result.slice(skip, skip + parseInt(limit));

    res.json({
      success: true,
      count: paginated.length,
      total,
      page: parseInt(page),
      totalPages: Math.ceil(total / limit),
      data: paginated
    });
  } catch (error) {
    console.error('❌ Get lead manager created appointments error:', error);
    res.status(500).json({
      success: false,
      error: {
        code: 'FETCH_LEAD_MANAGER_APPOINTMENTS_FAILED',
        message: error.message
      }
    });
  }
};

module.exports = {
  submitAppointmentRequest,
  getAppointmentRequest,
  getAllAppointmentRequests,
  updateAppointmentStatus,
  scheduleAppointment,
  addCommunication,
  deleteAppointmentRequest,
  getMyAppointments,
  getClientAppointments,
  getMyCreatedAppointments
};